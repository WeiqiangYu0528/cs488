// Fall 2023

#include "IndexExample.hpp"

int main( int argc, char **argv ) 
{
	CS488Window::launch( argc, argv, new IndexExample(), 1024, 768, "Index Rendering "
			"Example" );
	return 0;
}
