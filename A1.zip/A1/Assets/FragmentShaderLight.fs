#version 330

out vec4 fragColor;

void main() {
	fragColor = vec4(1.0);
}
